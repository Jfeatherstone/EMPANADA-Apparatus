# Wheatstone-Bridge-Amplifier-Shield
Find the product [here](http://www.robotshop.com/en/strain-gauge-load-cell-amplifier-shield-2ch.html).
